package com.britishtime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpokenTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpokenTimeApplication.class, args);
	}

}
