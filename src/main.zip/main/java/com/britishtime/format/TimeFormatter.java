package com.britishtime.format;


public interface TimeFormatter {
    String format(int hour, int minute);
}

